## What
Describe the change (new persona, fix, template, example).

## Why
What problem does it solve and for whom?

## Checklist
- [ ] File starts with a `# ` title and has Objective, Rules, and Output Format sections (for personas)
- [ ] No instructions to deceive, plagiarize, or evade detection or platform rules
- [ ] No unverifiable promises (for example guaranteed percentages or rankings)
- [ ] `python scripts/validate.py` passes
- [ ] Added or updated an example or eval case when behavior changes
