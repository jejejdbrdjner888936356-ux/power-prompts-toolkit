---
name: Feature request
about: Suggest a persona, template, command, or improvement
labels: enhancement
---

**What do you want added?**

**Who needs it and why?**

**Example prompt and ideal output**
