---
name: Bug report
about: A file gives wrong, harmful, or inconsistent behavior
labels: bug
---

**File**
Which file or persona?

**Prompt used**

**Expected behavior**

**Actual behavior**

**Model and interface** (claude.ai, API, Claude Code, version)
