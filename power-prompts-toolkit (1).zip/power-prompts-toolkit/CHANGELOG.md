# Changelog

All notable changes to this project are documented here. Format based on Keep a Changelog.

## [1.0.0]
### Added
- `CLAUDE.md` strict output rules and `ar/CLAUDE.ar.md`.
- `SKILL.md` with routing to all modules.
- `optimization/`: token-guard, data-analyst, artifacts-designer.
- `engineering/`: security-audit, test-engineer, code-transpiler, documentation-pro, devops-architect, architecture-reviewer, code-reviewer, debugger, commit-writer, sql-optimizer.
- `personas/`: ghost-writer, conversion-copywriter, expert-tutor, seo-architect, threads-creator, product-manager, meeting-summarizer, fact-checker.
- `ar/`: Arabic writer, RTL UI designer, Arabic SEO, Arabic README.
- `claude-code/`: slash commands and subagents; `install.sh`.
- `templates/`: CLAUDE.md templates for Next.js, Django, NestJS, Flutter, Laravel.
- `safety/untrusted-content.md`: prompt-injection defense rules.
- `examples/`, `evals/`, `scripts/validate.py`, GitHub workflow and templates.
