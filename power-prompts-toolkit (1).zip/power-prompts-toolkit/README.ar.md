# 🚀 حزمة Power Prompts (بالعربي)

**مجموعة مفتوحة المصدر من قواعد الإخراج الصارمة والشخصيات المتخصصة لـ Claude و Claude Code.**

---

## ✨ ماذا في الحزمة

| 📦 المجلد | 🎯 الفائدة |
| :--- | :--- |
| `CLAUDE.md` / `ar/CLAUDE.ar.md` | ردود مباشرة وكود كامل بلا اختصار |
| `optimization/` | توفير التوكنز، تحليل البيانات، تصميم Artifacts |
| `engineering/` | أمن، اختبارات، تحويل لغات، توثيق، DevOps، مراجعة كود، تصحيح أخطاء، SQL |
| `personas/` | كتابة، إعلانات، تبسيط، SEO، منشورات، إدارة منتج، محاضر اجتماعات، تدقيق حقائق |
| `ar/` | كاتب عربي، واجهات RTL، SEO عربي |
| `claude-code/` | أوامر مخصصة ووكلاء فرعيون جاهزون لـ Claude Code |
| `templates/` | قوالب `CLAUDE.md` لـ Next.js وDjango وNestJS وFlutter وLaravel |
| `safety/` | التعامل مع المحتوى غير الموثوق (حماية من prompt injection) |
| `examples/` | أمثلة قبل/بعد توضيحية |
| `evals/` | حالات اختبار لقياس عمل المهارة |

---

## ⚡ البدء السريع

### في مشاريع Claude (claude.ai)
1. افتح **Project** في [claude.ai](https://claude.ai).
2. من *Project knowledge* أضف الملفات، أو ارفع المجلد كاملاً.
3. انسخ محتوى `ar/CLAUDE.ar.md` (أو `CLAUDE.md`) إلى خانة **Instructions**.

### كمهارة (Skill)
اضغط المجلد مع بقاء `SKILL.md` في جذره وارفعه من **Settings → Capabilities → Skills**.

### في Claude Code
شغّل `./install.sh /path/to/your/project` فيُنسخ `CLAUDE.md` وأوامر `/review` و`/test` و`/commit` ... والوكلاء إلى `.claude/`. راجع `claude-code/README.md`.

---

## 🎭 طريقة الاستخدام
- *"استخدم شخصية الكاتب العربي واكتب مقالة عن ..."*
- *"استخدم شخصية security-audit وافحص هذا الكود."*
- *"استخدم قالب Next.js وأنشئ لي CLAUDE.md لمشروعي."*

> ⚠️ **استخدام مسؤول:** التزم بسياسات جهتك بشأن الذكاء الاصطناعي. لا توجد أداة أو موجّه يضمن نتيجة مع كواشف النصوص المولَّدة.

## 📄 الرخصة
MIT. راجع `LICENSE`.
