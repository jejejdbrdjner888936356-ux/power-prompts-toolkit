# CLAUDE.md — Django

## Commands
- Create venv: `python -m venv .venv && source .venv/bin/activate`
- Install: `pip install -r requirements.txt`
- Migrate: `python manage.py migrate`
- Run: `python manage.py runserver`
- Test: `python manage.py test` (or `pytest` if configured)
- Lint/format: use the project's configured tools (for example `ruff`, `black`).

## Conventions
- One Django app per domain concept; keep apps small and cohesive.
- Fat models are acceptable for data rules; put multi-model business logic in `services.py`; keep views thin.
- Always create and commit migrations (`makemigrations`); never edit applied migrations.
- Use the ORM; avoid raw SQL, and when needed use parameters. Use `select_related` and `prefetch_related` to prevent N+1 queries.
- Settings from environment variables; `DEBUG=False` and a strong `SECRET_KEY` in production. Never commit secrets.
- Validate input with forms or serializers (Django REST Framework if used); enforce permissions on every view.
- Write tests with factories or fixtures; test permissions and edge cases.

## Rules
- Do not run destructive management commands (`flush`, database drops) without asking.
- Follow `CLAUDE.md` output rules from the toolkit root.
