# CLAUDE.md — Laravel (PHP)

## Commands
- Install: `composer install` and `npm install`
- Env: `cp .env.example .env && php artisan key:generate`
- Migrate: `php artisan migrate`
- Serve: `php artisan serve`
- Test: `php artisan test`
- Lint/format: the project's configured tool (for example `./vendor/bin/pint`).

## Conventions
- Controllers stay thin; use Form Requests for validation, Actions or Services for business logic, and Policies for authorization.
- Eloquent: define relationships, use eager loading (`with`) to prevent N+1 queries, mass assignment protection via `$fillable`.
- Always create migrations; never edit migrations that already ran in shared environments.
- Use queues for slow work; use events and listeners for side effects.
- Use API Resources for JSON responses.
- Configuration through `.env` and `config/*.php`; never call `env()` outside config files; never commit `.env`.
- Write feature tests for routes and policies; use factories and `RefreshDatabase`.

## Rules
- Do not run `migrate:fresh` or other destructive commands without asking.
- Follow `CLAUDE.md` output rules from the toolkit root.
