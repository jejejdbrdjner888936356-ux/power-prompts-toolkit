# CLAUDE.md — NestJS (TypeScript)

## Commands
- Install: `npm install`
- Dev: `npm run start:dev`
- Build: `npm run build`
- Unit tests: `npm test`
- E2E tests: `npm run test:e2e`
- Lint: `npm run lint`

(Verify against `package.json`.)

## Conventions
- Feature modules: `module`, `controller`, `service`, `dto`, `entities` per feature.
- Controllers handle HTTP only; business logic lives in services; data access in repositories or the ORM layer.
- Validate every request with DTOs, `class-validator`, and a global `ValidationPipe` (`whitelist: true`, `transform: true`).
- Use dependency injection; avoid manual instantiation of providers.
- Configuration via `@nestjs/config` and environment variables; no secrets in code.
- Use guards for authentication and authorization; interceptors for cross-cutting concerns; exception filters for consistent errors.
- Document the API with `@nestjs/swagger` decorators.
- Unit-test services with mocked providers; use e2e tests for critical flows.

## Rules
- Do not change the ORM or database without asking.
- Follow `CLAUDE.md` output rules from the toolkit root.
