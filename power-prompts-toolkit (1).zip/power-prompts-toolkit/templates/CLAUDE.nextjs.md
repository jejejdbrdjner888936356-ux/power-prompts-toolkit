# CLAUDE.md — Next.js (App Router, TypeScript)

## Commands
- Install: `npm install`
- Dev server: `npm run dev`
- Build: `npm run build`
- Lint: `npm run lint`
- Type check: `npx tsc --noEmit`
- Test: `npm test`

(Adjust to your package manager and scripts; check `package.json` first.)

## Conventions
- App Router in `app/`; server components by default. Add `"use client"` only for state, effects, or browser APIs.
- Fetch data in server components or route handlers; mutate with server actions or `app/api/**/route.ts`.
- Strict TypeScript; no `any`. Validate external input with a schema library (for example Zod).
- Colocate components by feature; shared UI in `components/`; helpers in `lib/`.
- Environment variables: server-only secrets never prefixed with `NEXT_PUBLIC_`. Never commit `.env*`.
- Use `next/image` and `next/link`; set metadata via the `metadata` export.
- Handle `loading.tsx` and `error.tsx` for every route segment that fetches data.

## Rules
- Do not change the Next.js major version or the router type without asking.
- Run lint, type check, and tests before declaring a task done.
- Follow `CLAUDE.md` output rules from the toolkit root.
