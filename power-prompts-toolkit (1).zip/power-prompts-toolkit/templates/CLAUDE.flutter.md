# CLAUDE.md — Flutter (Dart)

## Commands
- Get packages: `flutter pub get`
- Run: `flutter run`
- Analyze: `flutter analyze`
- Format: `dart format .`
- Test: `flutter test`
- Build Android: `flutter build apk` or `flutter build appbundle`
- Build iOS: `flutter build ios`

## Conventions
- Follow the project's state management (Riverpod, Bloc, Provider); do not mix several without a reason.
- Structure by feature: `lib/features/<feature>/{data,domain,presentation}`.
- Keep widgets small; extract widgets instead of nesting deeply. Use `const` constructors wherever possible.
- Never block the UI thread; use `async` and isolates for heavy work.
- Dispose controllers, streams, and subscriptions.
- Localize all user-facing strings (`flutter_localizations`, ARB files); support RTL layouts using `EdgeInsetsDirectional` and `AlignmentDirectional`.
- Secrets are not stored in source; use secure storage and build-time configuration.
- Write widget tests for key screens and unit tests for logic.

## Rules
- Run `flutter analyze` and `flutter test` before finishing.
- Do not upgrade the Flutter SDK or major dependencies without asking.
- Follow `CLAUDE.md` output rules from the toolkit root.
