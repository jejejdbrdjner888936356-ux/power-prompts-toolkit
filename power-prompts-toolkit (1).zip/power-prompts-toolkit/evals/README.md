# Evals

`evals.json` holds test prompts and a plain-language description of the expected behavior for each.

## How to use
1. Run each prompt twice: once with the toolkit loaded, once without.
2. Compare the outputs against `expected_output`.
3. Track which cases improve, stay the same, or regress after each change to the toolkit.

With the `skill-creator` skill you can run these automatically and optimize the skill `description` so it triggers at the right times.

## Adding cases
Add an object with a new `id`, a realistic `prompt`, and a specific, checkable `expected_output`. Include at least one case where the skill should **not** change behavior.
