#!/usr/bin/env python3
"""Validate the toolkit structure. Exit code 1 on any failure."""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONTENT_DIRS = ["optimization", "engineering", "personas", "ar", "safety"]
errors: list[str] = []


def fail(message: str) -> None:
    errors.append(message)


def check_skill_file() -> None:
    skill = ROOT / "SKILL.md"
    if not skill.exists():
        fail("SKILL.md is missing")
        return
    text = skill.read_text(encoding="utf-8")
    match = re.match(r"^---\n(.*?)\n---\n", text, re.DOTALL)
    if not match:
        fail("SKILL.md has no YAML frontmatter")
        return
    front = match.group(1)
    name = re.search(r"^name:\s*(.+)$", front, re.MULTILINE)
    description = re.search(r"^description:\s*(.+)$", front, re.MULTILINE)
    if not name:
        fail("SKILL.md frontmatter lacks name")
    else:
        value = name.group(1).strip()
        if not re.fullmatch(r"[a-z0-9-]{1,64}", value):
            fail(f"skill name '{value}' must be lowercase letters, digits, hyphens (max 64)")
        if "claude" in value or "anthropic" in value:
            fail(f"skill name '{value}' contains a reserved word")
    if not description:
        fail("SKILL.md frontmatter lacks description")
    elif len(description.group(1).strip()) > 1024:
        fail("skill description exceeds 1024 characters")
    for referenced in set(re.findall(r"`((?:[\w.-]+/)*[\w.-]+\.md)`", text)):
        if not (ROOT / referenced).exists():
            fail(f"SKILL.md references missing file: {referenced}")
    if len(text.splitlines()) > 500:
        fail("SKILL.md is longer than 500 lines")


def check_markdown_files() -> None:
    for directory in CONTENT_DIRS:
        for path in sorted((ROOT / directory).glob("*.md")):
            text = path.read_text(encoding="utf-8").strip()
            relative = path.relative_to(ROOT)
            if not text:
                fail(f"{relative} is empty")
            elif not text.startswith("# "):
                fail(f"{relative} must start with a '# ' title")
            if re.search(r"^\s*(//|#)\s*\.\.\.\s*$", text, re.MULTILINE):
                fail(f"{relative} contains an elision placeholder")


def check_claude_code_files() -> None:
    for kind, required in (("commands", ["description"]), ("agents", ["name", "description"])):
        for path in sorted((ROOT / "claude-code" / kind).glob("*.md")):
            text = path.read_text(encoding="utf-8")
            match = re.match(r"^---\n(.*?)\n---\n", text, re.DOTALL)
            relative = path.relative_to(ROOT)
            if not match:
                fail(f"{relative} lacks frontmatter")
                continue
            for key in required:
                if not re.search(rf"^{key}:\s*\S", match.group(1), re.MULTILINE):
                    fail(f"{relative} frontmatter lacks '{key}'")


def check_evals() -> None:
    path = ROOT / "evals" / "evals.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        fail(f"evals/evals.json invalid: {error}")
        return
    ids = [item.get("id") for item in data.get("evals", [])]
    if len(ids) != len(set(ids)):
        fail("evals/evals.json has duplicate ids")
    for item in data.get("evals", []):
        for key in ("id", "prompt", "expected_output"):
            if key not in item:
                fail(f"eval {item.get('id')} lacks '{key}'")


def main() -> int:
    check_skill_file()
    check_markdown_files()
    check_claude_code_files()
    check_evals()
    if errors:
        print("Validation failed:")
        for error in errors:
            print(f" - {error}")
        return 1
    print("All checks passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
