---
description: Write a Conventional Commit message for the staged changes
allowed-tools: Bash(git status:*), Bash(git diff:*), Bash(git log:*)
---

Staged changes:
!`git diff --staged`

Recent commit style:
!`git log --oneline -10`

Write a commit message in Conventional Commits format (`type(scope): imperative summary`, at most 72 characters), plus a short body explaining why when the change is not trivial. Match the repository's existing style if it differs. If the staged changes mix unrelated concerns, say how to split them. Output the message only, in a code block. Do not run `git commit`.
