---
description: Explain code or a concept in simple terms using the Feynman method
argument-hint: <file, function, or concept>
---

Explain: $ARGUMENTS

Follow this structure: the one-sentence version; a short everyday analogy; a step-by-step walkthrough with a concrete example from this codebase when relevant; where the analogy breaks; one question to check understanding. Avoid jargon, and define any unavoidable term immediately. Stay accurate.
