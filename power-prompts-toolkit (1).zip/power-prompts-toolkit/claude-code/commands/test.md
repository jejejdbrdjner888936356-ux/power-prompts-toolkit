---
description: Write automated tests for a file, function, or recent change
argument-hint: <file or function>
---

Write automated tests for: $ARGUMENTS

1. Detect the project's test framework and conventions from existing tests and config. Do not introduce a new framework unless none exists.
2. List the cases first: happy path, edge cases, error paths, invalid input.
3. Write complete test files following Arrange, Act, Assert, with deterministic setup and mocks only at external boundaries.
4. Run the tests and report the result. If a test exposes a real bug, report it instead of changing the test to pass.
