# Claude Code Toolkit

Custom slash commands and subagents for Claude Code.

## Install
From the toolkit root:

```bash
./install.sh /path/to/your/project
```

This copies:
- `claude-code/commands/*.md` to `<project>/.claude/commands/`
- `claude-code/agents/*.md` to `<project>/.claude/agents/`

Install them for all projects by copying into `~/.claude/commands/` and `~/.claude/agents/` instead.

## Commands
| Command | Purpose |
| :--- | :--- |
| `/review [focus]` | Review uncommitted changes |
| `/test <target>` | Write and run tests |
| `/commit` | Draft a Conventional Commit message for staged changes |
| `/explain <target>` | Feynman-style explanation |
| `/audit <path>` | Defensive security audit |

## Subagents
`security-reviewer`, `code-reviewer`, `doc-writer`, `test-writer`.

## Important
Claude Code's file formats and frontmatter fields can change between versions. Check the current official documentation for slash commands and subagents if a command or agent does not load, and adjust the frontmatter (`description`, `allowed-tools`, `tools`) accordingly.
