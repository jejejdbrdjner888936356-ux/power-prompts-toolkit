#!/usr/bin/env bash
# Install the Claude Code commands, agents, and optional CLAUDE.md into a project.
# Usage: ./install.sh /path/to/project [template]
#   template: nextjs | django | nestjs | flutter | laravel (optional)
set -euo pipefail

TOOLKIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${1:-}"
TEMPLATE="${2:-}"

if [[ -z "$TARGET" || ! -d "$TARGET" ]]; then
  echo "Usage: $0 /path/to/project [nextjs|django|nestjs|flutter|laravel]" >&2
  exit 1
fi

mkdir -p "$TARGET/.claude/commands" "$TARGET/.claude/agents"
cp "$TOOLKIT_DIR"/claude-code/commands/*.md "$TARGET/.claude/commands/"
cp "$TOOLKIT_DIR"/claude-code/agents/*.md "$TARGET/.claude/agents/"
echo "Installed commands and agents into $TARGET/.claude/"

if [[ -e "$TARGET/CLAUDE.md" ]]; then
  echo "CLAUDE.md already exists in the project; not overwriting."
else
  if [[ -n "$TEMPLATE" ]]; then
    TEMPLATE_FILE="$TOOLKIT_DIR/templates/CLAUDE.$TEMPLATE.md"
    if [[ ! -f "$TEMPLATE_FILE" ]]; then
      echo "Unknown template: $TEMPLATE" >&2
      exit 1
    fi
    { cat "$TOOLKIT_DIR/CLAUDE.md"; printf '\n\n---\n\n'; cat "$TEMPLATE_FILE"; } > "$TARGET/CLAUDE.md"
  else
    cp "$TOOLKIT_DIR/CLAUDE.md" "$TARGET/CLAUDE.md"
  fi
  echo "Created $TARGET/CLAUDE.md"
fi
