# Examples

Illustrative before/after pairs showing the intent of each rule set. They are **hand-written to demonstrate the style**, not measured benchmark results. Real outputs vary by model and prompt; use `evals/` to test on your own cases.

| File | Rule set demonstrated |
| :--- | :--- |
| `01-claude-md-rules.md` | `CLAUDE.md` (no filler, complete code) |
| `02-security-audit.md` | `engineering/security-audit.md` |
| `03-test-engineer.md` | `engineering/test-engineer.md` |
| `04-expert-tutor.md` | `personas/expert-tutor.md` |
| `05-threads-creator.md` | `personas/threads-creator.md` |
