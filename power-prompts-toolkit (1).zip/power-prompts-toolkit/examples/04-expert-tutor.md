# Example: expert tutor

**Prompt:** Explain what a hash function is.

## Before
> A hash function maps data of arbitrary size to fixed-size values using a deterministic algorithm with properties such as collision resistance.

## After (with expert-tutor.md)
**One sentence:** A hash function turns anything you give it into a short fingerprint.

**Analogy:** Imagine a machine that squeezes any book into a small stamp. The same book always gives the same stamp, and even one changed letter gives a very different stamp. You can't rebuild the book from the stamp.

**Steps:** Give the machine "cat" and get stamp A. Give it "cat" again and get A again. Give it "cap" and get a totally different stamp B.

**Where the analogy breaks:** Different books can, very rarely, make the same stamp (a collision). Good hash functions make that extremely unlikely.

**Check:** If two files have different stamps, can they be identical? Why not?
