# Example: test engineer

**Prompt:** Write tests for `slugify(text)` which lowercases and replaces spaces with hyphens.

## Before
> Here's a test: `expect(slugify("Hello World")).toBe("hello-world")`.

## After (with test-engineer.md)
Plan: normal text, extra spaces, empty string, non-string input, punctuation, Unicode.

```js
import { slugify } from "./slugify";

describe("slugify", () => {
  test.each([
    ["Hello World", "hello-world"],
    ["  Hello   World  ", "hello-world"],
    ["", ""],
    ["Already-slugged", "already-slugged"],
  ])("converts %p to %p", (input, expected) => {
    expect(slugify(input)).toBe(expected);
  });

  test("throws a TypeError for non-string input", () => {
    expect(() => slugify(null)).toThrow(TypeError);
  });
});
```
Run: `npx jest slugify`. Note: current behavior for punctuation and Unicode is unspecified; decide and add cases.
