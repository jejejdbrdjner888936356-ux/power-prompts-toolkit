# Example: security audit

**Prompt:** Review this Node.js route.
```js
app.get("/user", (req, res) => {
  db.query("SELECT * FROM users WHERE id = " + req.query.id, (err, rows) => res.json(rows));
});
```

## Before
> This looks fine for a simple app. You might want to add error handling.

## After (with security-audit.md)
| ID | Severity | Location | Issue |
| :-- | :-- | :-- | :-- |
| 1 | High | `GET /user` | SQL injection |
| 2 | Medium | `GET /user` | Missing authorization (IDOR) and over-exposed `SELECT *` |

**Finding 1.** Risk: an attacker can alter the query through `id` and read or modify data.

Fixed:
```js
app.get("/user", requireAuth, (req, res, next) => {
  const id = Number.parseInt(req.query.id, 10);
  if (!Number.isInteger(id)) return res.status(400).json({ error: "invalid id" });
  if (id !== req.user.id && !req.user.isAdmin) return res.status(403).json({ error: "forbidden" });
  db.query("SELECT id, name, email FROM users WHERE id = ?", [id], (err, rows) => {
    if (err) return next(err);
    res.json(rows[0] ?? null);
  });
});
```
Verify: request `?id=1 OR 1=1` returns 400; a normal user requesting another user's id returns 403.
