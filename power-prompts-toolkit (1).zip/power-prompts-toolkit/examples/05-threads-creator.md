# Example: threads creator

**Source idea:** "Most side projects fail because people never ship a first version."

## Before
> Many side projects fail. You should ship early. Shipping is important for success.

## After (with threads-creator.md, X thread excerpt)
1/ Most side projects don't die from bad ideas. They die in a folder called "almost done."

2/ The pattern: you polish the logo, rewrite the database twice, and never show anyone. Six months later the energy is gone.

3/ Fix: set a ship date 14 days out. Whatever works by then is version one.

Last/ Ship the ugly version. Reply with the project you've been polishing, and the date you'll ship it.
