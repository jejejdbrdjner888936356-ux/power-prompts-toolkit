# Example: CLAUDE.md rules

**Prompt:** Write a Python function that returns the n-th Fibonacci number.

## Before (typical verbose answer)
> Great question! I'd be happy to help. Here's a function that computes Fibonacci numbers. I hope this helps!
> ```python
> def fib(n):
>     # ... handle the rest here
> ```
> Let me know if you'd like changes!

Problems: filler on both ends, placeholder comment, no validation.

## After (with CLAUDE.md)
```python
def fibonacci(n: int) -> int:
    if not isinstance(n, int) or n < 0:
        raise ValueError("n must be a non-negative integer")
    previous, current = 0, 1
    for _ in range(n):
        previous, current = current, previous + current
    return previous
```
- Iterative: O(n) time, O(1) space.
- Raises `ValueError` for negative or non-integer input.
