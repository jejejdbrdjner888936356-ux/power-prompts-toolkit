# 🚀 Claude Power Prompts

**A small, open-source toolkit of strict output rules and expert personas for Claude.**

Stop getting apologies, filler, and half-finished code. Get direct answers and complete files.

---

## ✨ What You Get

| 📦 File | 🎯 What it fixes | ✅ Result |
| :--- | :--- | :--- |
| **`CLAUDE.md`** | Apologies, long intros, `// ...` placeholders | Direct answers and fully written, runnable code |
| **`SKILL.md`** | Using the whole toolkit as a Claude Skill | Rules and personas loaded on demand |
| **`optimization/`** | Wasted tokens, unfocused data analysis, plain UIs | Token-saving rules, data analyst, Tailwind + Lucide artifact designer |
| **`engineering/`** | Unreviewed, untested, undocumented code | Security audit, tests, transpiler, docs, DevOps, architecture review |
| **`personas/seo-architect.md`** and **`threads-creator.md`** | Weak SEO content and unstructured social posts | Intent-driven SEO plans and X/LinkedIn threads |
| **`personas/ghost-writer.md`** | Robotic, generic AI phrasing | Natural, specific, voiced writing |
| **`personas/conversion-copywriter.md`** | Weak, vague sales copy | Persuasive copy built on **AIDA** and **PAS** |
| **`personas/expert-tutor.md`** | Confusing, jargon-heavy explanations | **Feynman-style** explanations anyone can follow |

---

## ⚡ Quick Start (3 Steps)

### 🅰️ In Claude Projects (claude.ai)

1. **Open** a Project on [claude.ai](https://claude.ai) (Pro, Team, or Enterprise).
2. **Add knowledge:** in *Project knowledge*, click **+** and choose **GitHub**, then paste this repository's URL and sync. *(Or upload the files manually.)*
3. **Activate the rules:** copy the contents of `CLAUDE.md` into the Project's **Instructions** box. To use a persona, paste it too, or start a chat with: *"Use the persona in `conversion-copywriter.md`."*

> 💡 Files in Project knowledge are reference material Claude can read. The **Instructions** box is what Claude follows in every chat, so that is where the rules belong.

### 🅱️ As a Claude Skill

Zip this folder (with `SKILL.md` at its root) and upload it in **Settings → Capabilities → Skills**, or place it in your Claude Code skills directory. Claude loads the rules and personas only when a request matches the skill description.

### 🅲 In Claude Code

Put `CLAUDE.md` in the root of your project. Claude Code reads it automatically at the start of every session.

---

## 🗂️ Repository Map

| 📁 Folder | 📌 Contents |
| :--- | :--- |
| `optimization/` | Token guard, data analyst, artifacts designer |
| `engineering/` | Security audit, tests, transpiler, docs, DevOps, architecture, code review, debugger, commit writer, SQL optimizer |
| `personas/` | Writers, copywriter, tutor, SEO, threads, product manager, meeting summarizer, fact-checker |
| `ar/` | Arabic CLAUDE rules, Arabic writer, RTL UI designer, Arabic SEO (`README.ar.md` for the Arabic README) |
| `claude-code/` | Slash commands (`/review`, `/test`, `/commit`, `/explain`, `/audit`) and subagents |
| `templates/` | `CLAUDE.md` starters for Next.js, Django, NestJS, Flutter, Laravel |
| `safety/` | Prompt-injection defense rules for untrusted content |
| `examples/` | Illustrative before/after pairs (hand-written, not benchmarks) |
| `evals/` | Test prompts with expected behavior, compatible with `skill-creator` |

### One-command install for Claude Code
```bash
./install.sh /path/to/your/project nextjs   # template optional: nextjs | django | nestjs | flutter | laravel
```

### Validate before contributing
```bash
python scripts/validate.py
```

---

## 🎭 Using Personas

Start your message with the persona, then your task:

- *"Use the expert-tutor persona. Explain how HTTPS works."*
- *"Use the conversion-copywriter persona. Write a landing page for my budgeting app."*
- *"Use the ghost-writer persona. Rewrite this email so it sounds like me."*

---

## 🧠 Philosophy

- **Strict, not sneaky.** Rules are explicit and honest.
- **Quality over tricks.** Natural writing comes from specificity and voice, not from evading tools.
- **Transparent.** Everything is plain Markdown you can read, edit, and fork.

> ⚠️ **Responsible use:** Follow the AI-use policies of your school, employer, or publisher, and disclose AI assistance where required. No prompt can guarantee a result with AI-detection software.

---

## 🤝 Contributing

See `CONTRIBUTING.md`.

---

## 📄 License

Released under the **MIT License**. See `LICENSE`.
