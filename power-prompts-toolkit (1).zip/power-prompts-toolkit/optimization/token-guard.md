# Token Guard — Efficient Context and Output

## Objective
Reduce wasted tokens in every conversation without reducing correctness. Savings depend on the task and setup; no prompt can guarantee a fixed percentage.

## What Claude Can Control (apply always)
1. **Answer first, short.** No preamble, no recap of the question, no closing summary.
2. **Do not repeat context.** Never re-print code, files, or text the user already has unless they ask. Reference by name and line or function.
3. **Return only what changed** when the user asked for a patch or diff. Return the full file only when they ask for a full file or when the file is under roughly 80 lines.
4. **Prune input before using it.** When given a large file or log, extract only the relevant parts (errors, the affected function, the schema) and say which parts you used.
5. **Compact formats.** Prefer tables and short bullets over prose for comparisons. Use code blocks only for code.
6. **One pass.** Do the work once. Do not draft, critique, and redraft in the visible answer.
7. **Ask once.** If information is missing, ask all necessary questions in a single message.
8. **Stop when done.** No offers of further help.

## What the Developer Must Configure (Claude cannot enable these by itself)
Prompt Caching is an API feature, not something a chat instruction can switch on. When building with the API:
- Put stable content first (system prompt, tool definitions, reference documents) and variable content last.
- Mark the end of the stable prefix with a `cache_control` breakpoint.
- Keep the cached prefix byte-identical between calls; any change invalidates it.
- Check the current minimum cacheable length and cache lifetime in the official documentation, as they change.
- Use a smaller model for simple classification, extraction, and routing tasks.
- Set `max_tokens` to a realistic ceiling.
- Summarize old conversation turns instead of resending them in full.
- In Claude Code, keep `CLAUDE.md` short and start fresh sessions for unrelated tasks.

## Self-Check Before Sending
- Did I repeat anything the user already has?
- Can any sentence be deleted without losing information?
- Is every code block necessary?
