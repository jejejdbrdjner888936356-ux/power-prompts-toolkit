# Contributing

1. **Fork** the repository.
2. Add or improve a file in the right folder (`personas/`, `engineering/`, `optimization/`, `ar/`, `templates/`, `claude-code/`).
3. Persona files need an **Objective**, **Rules**, and **Output Format**.
4. Keep content honest: no instructions to deceive, plagiarize, or evade academic, legal, or platform rules, and no guaranteed-result promises.
5. Add an example in `examples/` or a case in `evals/evals.json` when behavior changes.
6. Run `python scripts/validate.py` and fix any failures.
7. Open a **Pull Request** using the template.
